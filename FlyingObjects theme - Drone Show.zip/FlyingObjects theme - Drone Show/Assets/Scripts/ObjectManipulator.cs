using UnityEngine;
using UnityEngine.SceneManagement;

public class ObjectManipulator : MonoBehaviour
{
    public GameObject plane;
    [SerializeField] private float value = 0.1f;
    [SerializeField] private Vector3 sizeChangeValue = new Vector3(10, 10f, 10f);
    [SerializeField] private float rotationValue = 1.5f;
    private Vector3 startposition;
    private Quaternion startrotation;
    private Vector3 startScale;

    public void Start(){
        startposition = new Vector3(plane.transform.position.x, plane.transform.position.y, plane.transform.position.z);
        startrotation = new Quaternion(plane.transform.rotation.x, plane.transform.rotation.y, plane.transform.rotation.z, plane.transform.rotation.w);
        startScale = new Vector3(plane.transform.localScale.x, plane.transform.localScale.y, plane.transform.localScale.z);
    }

    public void MoveRight(){
        plane.transform.position += new Vector3(value, 0, 0);
    }

    public void MoveLeft(){
        plane.transform.position -= new Vector3(value, 0, 0);
    }

    public void MoveUp(){
        plane.transform.position += new Vector3(0, value, 0);
    }

    public void MoveDown(){
        plane.transform.position -= new Vector3(0, value, 0);
    }

    public void ScaleUp(){
        // if scale is more than 10f, then don't scale up
        if(plane.transform.localScale.x > 20 || plane.transform.localScale.y > 20 || plane.transform.localScale.z > 20){
            return;
        }
        plane.transform.localScale += sizeChangeValue;
    }

    public void ScaleDown(){
        // if scale is less than 0.1, then don't scale down
        if(plane.transform.localScale.x < 0.5 || plane.transform.localScale.y < 0.5 || plane.transform.localScale.z < 0.5){
            return;
        }
        plane.transform.localScale -= sizeChangeValue;
    }

    public void Reset(){
        plane.transform.position = startposition;
        plane.transform.localScale = new Vector3(1, 1, 1);
        plane.transform.rotation = startrotation;
        plane.transform.localScale = startScale;
    }

    public void RotateRight(){
        plane.transform.Rotate(0, rotationValue, 0);
    }

    public void RotateLeft(){
        plane.transform.Rotate(0, -rotationValue, 0);
    }

    public void MainMenu(){
        SceneManager.LoadScene("Menu");
    }
}
